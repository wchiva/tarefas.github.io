// Servidor estático mínimo para testar localmente a pasta dist/  →  http://localhost:8788
// Uso:  npm run dev   (ou:  npm run build && npm run serve)
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..', 'dist');
const port = Number(process.env.PORT || 8788);
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json' };

if (!fs.existsSync(root)) { console.error('Pasta dist/ não existe. Rode "npm run build" primeiro.'); process.exit(1); }

// aplica o CSP gerado em dist/_headers também localmente, para pegar violações antes de publicar
let csp = '';
try { csp = /Content-Security-Policy:\s*(.+)/.exec(fs.readFileSync(path.join(root, '_headers'), 'utf8'))?.[1] ?? ''; } catch { /* sem headers */ }

http.createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (p.endsWith('/')) p += 'index.html';
  const file = path.normalize(path.join(root, p));
  if (!file.startsWith(root) || path.basename(file).startsWith('_')) { res.writeHead(404); return res.end('Not found'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    const h = { 'Content-Type': types[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-store' };
    if (csp) h['Content-Security-Policy'] = csp;
    res.writeHead(200, h); res.end(data);
  });
}).listen(port, () => console.log(`FlowTask em http://localhost:${port}  (Ctrl+C para parar)`));
