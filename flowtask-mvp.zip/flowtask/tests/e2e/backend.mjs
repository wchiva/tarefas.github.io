// BACKEND DE TESTE (nunca vai para produção).
//
// O que é REAL aqui:   PostgreSQL (schema.sql + RLS + triggers) e o código da Edge Function (handler.ts).
// O que é SIMULADO:    Supabase Auth (login/sessão), PostgREST (tradução das consultas para SQL) e Realtime (SSE).
// Por isso estes testes provam as regras de negócio/segurança do banco e o comportamento da interface,
// mas NÃO substituem um teste final contra um projeto Supabase de verdade.
//
// Rodar:  tsx tests/e2e/backend.mjs   (precisa de PGHOST/PGUSER apontando para um Postgres descartável)
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import { makeHandler } from '../../supabase/functions/admin-users/handler.ts';

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../..');
const PORT = Number(process.env.E2E_PORT || 8799);
const DB = process.env.E2E_DB || 'ft_e2e';
const ORIGIN = `http://localhost:${PORT}`;

// ------------------------------------------------------------------ acesso ao Postgres via psql
function psql(sql, db = DB) {
  return new Promise((resolve) => {
    const p = spawn('psql', ['-X', '-A', '-t', '-q', '-d', db, '-v', 'ON_ERROR_STOP=1', '-v', 'VERBOSITY=verbose'], { env: process.env });
    let out = '', err = '';
    p.stdout.on('data', (d) => (out += d));
    p.stderr.on('data', (d) => (err += d));
    p.on('close', (code) => resolve({ out, err, code }));
    p.stdin.end(sql);
  });
}
const lit = (v) => (v === null || v === undefined ? 'NULL' : typeof v === 'boolean' || typeof v === 'number' ? String(v) : `'${String(v).replace(/'/g, "''")}'`);
const col = (c) => { if (!/^[a-z_]+$/.test(c)) throw new Error('coluna inválida'); return `"${c}"`; };

function buildStmt(spec) {
  const t = spec.table;
  if (!['tasks', 'profiles'].includes(t)) throw new Error('tabela inválida');
  const where = (spec.filters || []).map((f) => `${col(f.col)} = ${lit(f.val)}`).join(' and ');
  const W = where ? ` where ${where}` : '';
  let inner;
  if (spec.op === 'select') {
    inner = `select * from public.${t}${W}${spec.order ? ` order by ${col(spec.order.col)} ${spec.order.asc ? 'asc' : 'desc'}` : ''}`;
    return `select '@@' || coalesce(jsonb_agg(to_jsonb(q)), '[]'::jsonb)::text from (${inner}) q`;
  }
  if (spec.op === 'insert') {
    const cols = Object.keys(spec.values);
    inner = `insert into public.${t} (${cols.map(col).join(',')}) values (${cols.map((c) => lit(spec.values[c])).join(',')})`;
  } else if (spec.op === 'update') {
    inner = `update public.${t} set ${Object.entries(spec.patch).map(([c, v]) => `${col(c)} = ${lit(v)}`).join(', ')}${W}`;
  } else if (spec.op === 'delete') {
    inner = `delete from public.${t}${W}`;
  } else throw new Error('operação inválida');
  return `with q as (${inner} returning *) select '@@' || coalesce(jsonb_agg(to_jsonb(q)), '[]'::jsonb)::text from q`;
}

async function runAs(role, uid, stmt) {
  const claims = JSON.stringify(uid ? { sub: uid, role } : { role });
  const setRole = role === 'postgres' ? '' : `set local role ${role};`;
  const r = await psql(`begin;\n${setRole}\nselect set_config('request.jwt.claims', ${lit(claims)}, true) \\g /dev/null\n${stmt};\ncommit;\n`);
  if (r.code !== 0) {
    const m = /ERROR:\s+([0-9A-Z]{5}):\s*([^\n]*)/.exec(r.err);
    return { data: null, error: { code: m ? m[1] : 'XX000', message: m ? m[2] : r.err.trim() } };
  }
  const line = r.out.split('\n').find((l) => l.startsWith('@@'));
  return { data: line ? JSON.parse(line.slice(2)) : [], error: null };
}

// ------------------------------------------------------------------ "Auth" simulado
const state = { pw: new Map(), banned: new Set(), resetEmails: [], invites: [] };
const makeToken = (u) => Buffer.from(JSON.stringify({ sub: u.id, email: u.email, exp: Date.now() + 3600e3 })).toString('base64url');
function parseToken(t) {
  try { const j = JSON.parse(Buffer.from(String(t), 'base64url').toString()); return j.exp > Date.now() && j.sub ? j : null; } catch { return null; }
}
const bearer = (req) => /^Bearer\s+(.+)$/i.exec(req.headers.authorization || '')?.[1];

async function userByEmail(email) {
  const r = await runAs('postgres', null, `select '@@' || coalesce(jsonb_agg(to_jsonb(q)), '[]'::jsonb)::text from (select id, email from auth.users where lower(email) = lower(${lit(email)})) q`);
  return r.data?.[0] || null;
}

// "createClient" simulado usado pela Edge Function real
function fakeCreateClient() {
  const from = (table) => {
    const spec = { table, op: 'select', filters: [] };
    const b = {
      select() { return b; },
      update(patch) { spec.op = 'update'; spec.patch = patch; return b; },
      eq(c, v) { spec.filters.push({ col: c, val: v }); return b; },
      maybeSingle: async () => { const r = await runAs('service_role', null, buildStmt(spec)); return r.error ? { data: null, error: r.error } : { data: r.data[0] ?? null, error: null }; },
      then(res, rej) { return runAs('service_role', null, buildStmt(spec)).then((r) => ({ data: r.data, error: r.error })).then(res, rej); },
    };
    return b;
  };
  return {
    from,
    auth: {
      async getUser(jwt) {
        const u = parseToken(jwt);
        return u ? { data: { user: { id: u.sub, email: u.email } }, error: null } : { data: { user: null }, error: { message: 'invalid JWT' } };
      },
      admin: {
        async createUser({ email, password, user_metadata }) {
          if (await userByEmail(email)) return { data: null, error: { code: 'email_exists', status: 422, message: 'A user with this email address has already been registered' } };
          const id = crypto.randomUUID();
          const r = await runAs('postgres', null, `insert into auth.users (id, email, raw_user_meta_data) values (${lit(id)}, ${lit(email)}, ${lit(JSON.stringify(user_metadata || {}))}::jsonb) returning id`);
          if (r.error) return { data: null, error: r.error };
          if (password) state.pw.set(id, password);
          return { data: { user: { id } }, error: null };
        },
        async inviteUserByEmail(email, { data, redirectTo } = {}) {
          const res = await this.createUser({ email, user_metadata: data });
          if (!res.error) state.invites.push({ email, redirectTo });
          return res;
        },
        async updateUserById(id, attrs) {
          if (attrs.password) state.pw.set(id, attrs.password);
          if (attrs.ban_duration) { if (attrs.ban_duration === 'none') state.banned.delete(id); else state.banned.add(id); }
          return { data: { user: { id } }, error: null };
        },
        async deleteUser(id) { await runAs('postgres', null, `delete from auth.users where id = ${lit(id)} returning id`); return { error: null }; },
      },
    },
  };
}
const edgeHandler = makeHandler({ createClient: fakeCreateClient, env: (k) => ({ SUPABASE_URL: ORIGIN, SUPABASE_ANON_KEY: 'anon', SUPABASE_SERVICE_ROLE_KEY: 'service', SITE_URL: ORIGIN }[k]) });

// ------------------------------------------------------------------ "Realtime" simulado (SSE com checagem de RLS)
const clients = new Set();
async function broadcast(table, eventType, row) {
  for (const c of clients) {
    let visible = eventType === 'DELETE';
    if (!visible) {
      const r = await runAs('authenticated', c.uid, buildStmt({ table, op: 'select', filters: [{ col: 'id', val: row.id }] }));
      visible = !r.error && r.data.length > 0;
    }
    if (!visible) continue;
    const payload = eventType === 'DELETE' ? { eventType, table, new: {}, old: { id: row.id } } : { eventType, table, new: row, old: {} };
    c.res.write(`data: ${JSON.stringify(payload)}\n\n`);
  }
}
async function broadcastAllProfiles() {
  const r = await runAs('postgres', null, buildStmt({ table: 'profiles', op: 'select', filters: [] }));
  for (const row of r.data || []) await broadcast('profiles', 'UPDATE', row);
}

// ------------------------------------------------------------------ banco de testes
async function resetDb() {
  const admin = (sql, db = 'postgres') => psql(sql, db);
  await admin(`drop database if exists ${DB}`);
  await admin(`create database ${DB}`);
  for (const f of ['tests/sql/00_supabase_shim.sql', 'supabase/schema.sql']) {
    const r = await psql(fs.readFileSync(path.join(ROOT, f), 'utf8'));
    if (r.code !== 0) throw new Error(`falha ao aplicar ${f}: ${r.err}`);
  }
  state.pw.clear(); state.banned.clear(); state.resetEmails.length = 0; state.invites.length = 0;
  const seed = [['ana@teste.com', 'Ana Admin', 'Senha-Admin-1'], ['bruno@teste.com', 'Bruno Membro', 'Senha-Bruno-1'], ['carla@teste.com', 'Carla Membro', 'Senha-Carla-1']];
  for (const [email, name, pw] of seed) {
    const id = crypto.randomUUID();
    await psql(`insert into auth.users (id, email, raw_user_meta_data) values ('${id}', '${email}', '{"full_name":"${name}"}')`);
    state.pw.set(id, pw);
  }
  await psql(`update public.profiles set role='admin' where email='ana@teste.com'`); // como o passo a passo do SQL Editor
}

// ------------------------------------------------------------------ HTTP
const CSP = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'";
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.png': 'image/png' };
const readBody = (req) => new Promise((r) => { let b = ''; req.on('data', (d) => (b += d)); req.on('end', () => r(b)); });
const send = (res, status, obj) => { res.writeHead(status, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }); res.end(JSON.stringify(obj)); };

http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, ORIGIN);
    const p = url.pathname;

    // ---- arquivos estáticos (mesmo CSP de produção)
    if (req.method === 'GET' && !p.startsWith('/auth') && !p.startsWith('/rest') && !p.startsWith('/events') && !p.startsWith('/test')) {
      let file;
      if (p === '/config.js') {
        res.writeHead(200, { 'Content-Type': MIME['.js'], 'Content-Security-Policy': CSP });
        return res.end(`window.FLOWTASK_CONFIG = ${JSON.stringify({ SUPABASE_URL: ORIGIN, SUPABASE_ANON_KEY: 'anon-de-teste', HAS_LOGO: false })};`);
      }
      if (p === '/vendor/supabase.js') file = path.join(ROOT, 'tests/e2e/fake-supabase.js');
      else file = path.join(ROOT, 'public', p === '/' ? 'index.html' : p);
      if (!path.normalize(file).startsWith(ROOT) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); return res.end('404'); }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Content-Security-Policy': CSP, 'Cache-Control': 'no-store' });
      return res.end(fs.readFileSync(file));
    }

    // ---- utilidades de teste
    if (p === '/test/reset') { await resetDb(); return send(res, 200, { ok: true }); }
    if (p === '/test/state') return send(res, 200, { resetEmails: state.resetEmails, invites: state.invites, banned: [...state.banned] });
    if (p === '/test/sql' && req.method === 'POST') { const { sql } = JSON.parse(await readBody(req)); return send(res, 200, await runAs('postgres', null, `select '@@' || coalesce(jsonb_agg(to_jsonb(q)), '[]'::jsonb)::text from (${sql}) q`)); }

    // ---- Auth simulado
    if (p === '/auth/signin') {
      const { email, password } = JSON.parse(await readBody(req));
      const u = await userByEmail(String(email || ''));
      if (!u || state.pw.get(u.id) !== password) return send(res, 400, { message: 'Invalid login credentials', status: 400 });
      if (state.banned.has(u.id)) return send(res, 400, { message: 'User is banned', status: 400 });
      return send(res, 200, { access_token: makeToken(u), user: { id: u.id, email: u.email } });
    }
    if (p === '/auth/update') {
      const u = parseToken(bearer(req)); if (!u) return send(res, 401, { message: 'invalid JWT' });
      const { password } = JSON.parse(await readBody(req));
      if (!password || password.length < 8) return send(res, 422, { message: 'Password should be at least 8 characters' });
      if (state.pw.get(u.sub) === password) return send(res, 422, { message: 'New password should be different from the old password.' });
      state.pw.set(u.sub, password); return send(res, 200, { ok: true });
    }
    if (p === '/auth/reset') { const { email } = JSON.parse(await readBody(req)); state.resetEmails.push(email); return send(res, 200, {}); }

    // ---- PostgREST simulado
    if (p === '/rest') {
      const u = parseToken(bearer(req)); if (!u) return send(res, 401, { message: 'JWT inválido', code: 'PGRST301' });
      const spec = JSON.parse(await readBody(req));
      const r = await runAs('authenticated', u.sub, buildStmt(spec));
      if (r.error) return send(res, 400, r.error);
      send(res, 200, r.data);
      if (spec.op !== 'select') { // "Realtime": avisa os demais clientes conectados (respeitando o RLS)
        const evt = { insert: 'INSERT', update: 'UPDATE', delete: 'DELETE' }[spec.op];
        for (const row of r.data) await broadcast(spec.table, evt, row);
      }
      return;
    }

    // ---- Edge Function real
    if (p.startsWith('/functions/v1/admin-users')) {
      const body = req.method === 'POST' ? await readBody(req) : undefined;
      const resp = await edgeHandler(new Request(`${ORIGIN}${p}`, { method: req.method, headers: req.headers, body }));
      const text = await resp.text();
      res.writeHead(resp.status, Object.fromEntries(resp.headers)); res.end(text);
      if (resp.status === 200) broadcastAllProfiles();
      return;
    }

    // ---- Realtime (SSE)
    if (p === '/events') {
      const u = parseToken(url.searchParams.get('token')); if (!u) { res.writeHead(401); return res.end(); }
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store', Connection: 'keep-alive' });
      res.write(': ok\n\n');
      const c = { uid: u.sub, res }; clients.add(c);
      req.on('close', () => clients.delete(c));
      return;
    }
    res.writeHead(404); res.end('404');
  } catch (e) {
    console.error('[backend]', e);
    if (!res.headersSent) send(res, 500, { message: String(e.message || e) });
  }
}).listen(PORT, async () => {
  await resetDb();
  console.log(`E2E backend em ${ORIGIN} (banco ${DB})`);
});
