// Testes ponta a ponta no navegador (Chromium) com VÁRIOS usuários simultâneos.
// Backend: tests/e2e/backend.mjs  → Postgres REAL (schema + RLS) + Edge Function REAL; Auth/PostgREST/Realtime SIMULADOS.
//
//   PGHOST=... PGUSER=postgres NODE_PATH=<onde está o playwright> TSX=<caminho do tsx> node tests/e2e/run.mjs
import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../..');
const OUT = process.env.E2E_OUT || path.join(ROOT, 'tests/e2e/out');
const PORT = process.env.E2E_PORT || '8799';
const BASE = `http://localhost:${PORT}`;
fs.mkdirSync(OUT, { recursive: true });

// ------------------------------------------------------------------ mini framework
const results = [];
let current = '';
const allPages = [];
async function diag() {
  const out = [];
  for (const u of allPages) {
    try {
      const st = await u.page.evaluate(() => ({ app: !document.getElementById('screen-app').hidden, auth: !document.getElementById('screen-auth').hidden,
        views: ['form-login', 'form-forgot', 'form-newpass'].filter((i) => !document.getElementById(i).hidden), msg: document.getElementById('auth-message').textContent.slice(0, 80),
        toasts: document.getElementById('toasts').textContent.slice(0, 120), role: document.getElementById('me-role').textContent }));
      out.push(`       [${u.name}] ${JSON.stringify(st)}`);
    } catch (_) { /* página fechada */ }
  }
  return out.join('\n');
}
async function test(name, fn) {
  current = name;
  try { await fn(); results.push({ name, ok: true }); console.log('  PASS', name); }
  catch (e) { results.push({ name, ok: false, error: String(e.message || e).split('\n')[0] }); console.log('  FAIL', name, '\n       →', String(e.message || e).split('\n')[0]); console.log(await diag()); }
}
const ok = (cond, msg) => { if (!cond) throw new Error(msg || 'asserção falhou'); };
const stable = (v) => JSON.stringify(v, (k, x) => (x && typeof x === 'object' && !Array.isArray(x) ? Object.fromEntries(Object.entries(x).sort(([a], [b]) => a.localeCompare(b))) : x));
const eq = (got, want, msg) => { if (stable(got) !== stable(want)) throw new Error(`${msg || 'valores diferentes'}: obtido=${stable(got)} esperado=${stable(want)}`); };
async function waitFor(fn, what, timeout = 6000) {
  const t0 = Date.now(); let last;
  while (Date.now() - t0 < timeout) { try { last = await fn(); if (last) return last; } catch (e) { last = e; } await new Promise((r) => setTimeout(r, 100)); }
  throw new Error(`tempo esgotado esperando: ${what}`);
}

// ------------------------------------------------------------------ backend
const backend = spawn(process.env.TSX || 'tsx', [path.join(ROOT, 'tests/e2e/backend.mjs')], { env: { ...process.env, E2E_PORT: PORT }, cwd: ROOT, stdio: ['ignore', 'pipe', 'inherit'] });
await new Promise((resolve, reject) => {
  const t = setTimeout(() => reject(new Error('backend não subiu')), 30000);
  backend.stdout.on('data', (d) => { process.stdout.write(`[backend] ${d}`); if (String(d).includes('E2E backend em')) { clearTimeout(t); resolve(); } });
  backend.on('exit', (c) => reject(new Error('backend encerrou: ' + c)));
});

const sql = async (q) => (await (await fetch(`${BASE}/test/sql`, { method: 'POST', body: JSON.stringify({ sql: q }) })).json()).data;
const state = async () => (await fetch(`${BASE}/test/state`)).json();

// ------------------------------------------------------------------ navegador
const browser = await chromium.launch();
const problems = []; // erros de console / página / CSP / requisições com falha
const handled = [];  // erros tratados e registrados de propósito pelo app ("[FlowTask] ...")
let promptValue = 'Temp-98765';

async function newUser(name, viewport) {
  const ctx = await browser.newContext({ viewport: viewport || { width: 1280, height: 800 }, acceptDownloads: true });
  await ctx.addInitScript(() => {
    window.__csp = [];
    document.addEventListener('securitypolicyviolation', (e) => window.__csp.push(`${e.violatedDirective} ${e.blockedURI}`));
  });
  const page = await ctx.newPage();
  page.on('dialog', (d) => (d.type() === 'prompt' ? d.accept(promptValue) : d.accept()));
  page.on('console', (m) => {
    if (m.type() !== 'error') return;
    const t = m.text(), u = m.location().url || '';
    if (t.startsWith('[FlowTask]')) return handled.push(`${name}: ${t.slice(0, 120)}`);
    // respostas 4xx esperadas nos testes negativos (login errado, RLS negando, função recusando)
    if (/status of 4\d\d/.test(t) && /\/auth\/signin|\/rest|\/functions\//.test(u)) return;
    problems.push(`${name} console: ${t.slice(0, 200)}`);
  });
  page.on('pageerror', (e) => problems.push(`${name} pageerror: ${e.message}`));
  page.on('requestfailed', (r) => { if (!/\/events/.test(r.url())) problems.push(`${name} requestfailed: ${r.url()} ${r.failure()?.errorText}`); });
  const u = { name, ctx, page }; allPages.push(u);
  return u;
}

const visible = (page, sel) => page.locator(sel).isVisible();
async function login(page, email, pw) {
  await page.goto(BASE + '/');
  await page.locator('#login-email').waitFor({ state: 'visible' });
  await page.fill('#login-email', email);
  await page.fill('#login-password', pw);
  await page.click('#btn-login');
}
async function loginOk(u, email, pw) {
  await login(u.page, email, pw);
  await u.page.locator('#screen-app').waitFor({ state: 'visible', timeout: 8000 });
}
const colTitles = (page, col) => page.locator(`#col-${col} [data-task-id] h4, #col-${col} [data-task-id] button.font-semibold`).allTextContents();
const hasCard = async (page, title) => (await page.locator('[data-task-id]', { hasText: title }).count()) > 0;
const cardIn = (page, col, title) => page.locator(`#col-${col} [data-task-id]`, { hasText: title });

async function createTask(page, t) {
  await page.click('#btn-new-task');
  await page.locator('#modal-task').waitFor({ state: 'visible' });
  await page.fill('#task-title', t.title);
  if (t.desc != null) await page.fill('#task-desc', t.desc);
  if (t.priority) await page.selectOption('#task-priority', t.priority);
  if (t.due) await page.fill('#task-duedate', t.due);
  if (t.status) await page.selectOption('#task-status', t.status);
  if (t.assignee) await page.selectOption('#task-assignee', { label: t.assignee });
  await page.click('#btn-task-save');
  await page.locator('#modal-task').waitFor({ state: 'hidden' });
}

// parser CSV (RFC 4180) para validar a exportação
function parseCsv(text, sep) {
  const rows = []; let row = [], cell = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
    else if (c === '"') q = true;
    else if (c === sep) { row.push(cell); cell = ''; }
    else if (c === '\n') { row.push(cell.replace(/\r$/, '')); rows.push(row); row = []; cell = ''; }
    else cell += c;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  return rows;
}

const today = new Date();
const ym = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
const D = (day) => `${ym}-${String(day).padStart(2, '0')}`;

// =================================================================== ROTEIRO
console.log('\n== Acesso e sessão ==');
const admin = await newUser('Ana(admin)');
const bruno = await newUser('Bruno(membro)');
const carla = await newUser('Carla(membro)');

await test('01 visitante sem login vê só a tela de login (nenhum dado)', async () => {
  await admin.page.goto(BASE + '/');
  await admin.page.locator('#login-email').waitFor({ state: 'visible' });
  ok(await visible(admin.page, '#screen-auth'), 'tela de login deveria aparecer');
  ok(!(await visible(admin.page, '#screen-app')), 'app não pode aparecer sem login');
  eq(await admin.page.locator('#col-todo').innerHTML(), '', 'colunas devem estar vazias');
});

await test('02 login com senha errada mostra mensagem e não entra', async () => {
  await login(admin.page, 'ana@teste.com', 'senha-errada');
  await waitFor(async () => /incorretos/.test(await admin.page.locator('#auth-message').textContent()), 'mensagem de erro');
  ok(!(await visible(admin.page, '#screen-app')));
});

await test('03 login do administrador: nome e nível de acesso visíveis', async () => {
  await loginOk(admin, 'ana@teste.com', 'Senha-Admin-1');
  eq((await admin.page.locator('#me-name').textContent()).trim(), 'Ana Admin');
  eq((await admin.page.locator('#me-role').textContent()).trim(), 'Administrador');
  ok(await visible(admin.page, '#user-create-panel') || true); // painel fica na aba Usuários
});

await test('04 sessão persiste ao recarregar a página', async () => {
  await admin.page.reload();
  await admin.page.locator('#screen-app').waitFor({ state: 'visible', timeout: 8000 });
  eq((await admin.page.locator('#me-name').textContent()).trim(), 'Ana Admin');
});

await test('05 login do membro: nível "Membro" e sem painel de cadastro de usuários', async () => {
  await loginOk(bruno, 'bruno@teste.com', 'Senha-Bruno-1');
  eq((await bruno.page.locator('#me-role').textContent()).trim(), 'Membro');
  await bruno.page.click('nav[aria-label="Navegação principal"] [data-tab="users"]');
  ok(!(await visible(bruno.page, '#user-create-panel')), 'membro não pode ver o cadastro de usuários');
  eq(await bruno.page.locator('#users-list select').count(), 0, 'membro não vê controles de papel');
  await bruno.page.click('nav[aria-label="Navegação principal"] [data-tab="kanban"]');
});
await loginOk(carla, 'carla@teste.com', 'Senha-Carla-1');

console.log('\n== Tarefas, prioridades e sincronização ==');
await test('06 admin cria tarefa atribuída ao Bruno → aparece para o Bruno SEM recarregar (tempo real)', async () => {
  await createTask(admin.page, { title: 'Revisar contrato', desc: 'Cláusulas 3 e 4', priority: 'high', due: D(20), assignee: 'Bruno Membro' });
  await waitFor(async () => (await cardIn(admin.page, 'todo', 'Revisar contrato').count()) === 1, 'exatamente 1 card na tela do admin');
  await waitFor(() => hasCard(bruno.page, 'Revisar contrato'), 'card aparecer para o Bruno');
  await waitFor(() => hasCard(carla.page, 'Revisar contrato'), 'card aparecer para a Carla');
});

await test('07 prioridades têm cores distintas (alta=vermelho, média=âmbar, baixa=verde)', async () => {
  await createTask(admin.page, { title: 'Prio média', priority: 'medium' });
  await createTask(admin.page, { title: 'Prio baixa', priority: 'low' });
  const cls = async (t) => (await admin.page.locator('[data-task-id]', { hasText: t }).first().locator('span.rounded-full').first().getAttribute('class')) + ' ' + (await admin.page.locator('[data-task-id]', { hasText: t }).first().getAttribute('class'));
  const a = await cls('Revisar contrato'), m = await cls('Prio média'), b = await cls('Prio baixa');
  ok(/text-red-400/.test(a) && /border-l-red-500/.test(a), 'alta: ' + a);
  ok(/text-amber-400/.test(m) && /border-l-amber-400/.test(m), 'média: ' + m);
  ok(/text-emerald-400/.test(b) && /border-l-emerald-500/.test(b), 'baixa: ' + b);
  eq((await admin.page.locator('[data-task-id]', { hasText: 'Revisar contrato' }).locator('span.rounded-full').first().textContent()).trim(), 'Alta');
});

await test('08 membro cria tarefa; só pode atribuir a si; admin vê na hora; autor registrado', async () => {
  await bruno.page.click('#btn-new-task');
  const opts = await bruno.page.locator('#task-assignee option').allTextContents();
  eq(opts, ['Sem responsável', 'Bruno Membro'], 'opções de responsável do membro');
  await bruno.page.click('[data-close="modal-task"]');
  await createTask(bruno.page, { title: 'Pauta da reunião', priority: 'medium', assignee: 'Bruno Membro' });
  await waitFor(() => hasCard(admin.page, 'Pauta da reunião'), 'admin ver tarefa do Bruno');
  const r = await sql(`select p.full_name as autor from public.tasks t join public.profiles p on p.id = t.created_by where t.title = 'Pauta da reunião'`);
  eq(r[0].autor, 'Bruno Membro', 'created_by gravado pelo banco');
});

await test('09 membro altera o status da tarefa dele → salvo no banco e refletido para o admin', async () => {
  await cardIn(bruno.page, 'todo', 'Revisar contrato').locator('select').selectOption('in_progress');
  await waitFor(async () => (await colTitles(admin.page, 'in_progress')).some((t) => /Revisar contrato/.test(t)), 'card mover para "Em andamento" no admin');
  const r = await sql(`select status from public.tasks where title = 'Revisar contrato'`);
  eq(r[0].status, 'in_progress', 'status no banco');
});

await test('10 arrastar e soltar (drag & drop) muda o status e salva', async () => {
  const src = cardIn(admin.page, 'todo', 'Prio baixa');
  await src.dragTo(admin.page.locator('#col-done'));
  await waitFor(async () => (await sql(`select status from public.tasks where title='Prio baixa'`))[0].status === 'done', 'status done no banco');
  await waitFor(() => cardIn(carla.page, 'done', 'Prio baixa').count(), 'Carla ver na coluna Concluída');
});

await test('11 membro NÃO edita tarefa alheia na interface (somente leitura)', async () => {
  await waitFor(() => hasCard(bruno.page, 'Prio média'), 'tarefa visível ao Bruno');
  await cardIn(bruno.page, 'todo', 'Prio média').locator('h4, button.font-semibold').first().click();
  await bruno.page.locator('#modal-task').waitFor({ state: 'visible' });
  eq((await bruno.page.locator('#modal-title').textContent()).trim(), 'Detalhes da tarefa');
  ok(await bruno.page.locator('#btn-task-save').isHidden(), 'sem botão Salvar');
  ok(await bruno.page.locator('#task-title').isDisabled(), 'título desabilitado');
  ok(await bruno.page.locator('#btn-task-delete').isHidden(), 'sem botão Excluir');
  await bruno.page.click('[data-close="modal-task"]');
  ok(await cardIn(bruno.page, 'todo', 'Prio média').locator('select').isDisabled(), 'select de status desabilitado');
});

console.log('\n== Permissões aplicadas no BANCO (ataque direto à API como membro) ==');
await test('12 membro chamando a API direto: não altera/exclui tarefa alheia, não se promove, não atribui a outros', async () => {
  const taskId = (await sql(`select id from public.tasks where title='Prio média'`))[0].id;
  const brunoId = (await sql(`select id from public.profiles where email='bruno@teste.com'`))[0].id;
  const carlaId = (await sql(`select id from public.profiles where email='carla@teste.com'`))[0].id;
  const r = await bruno.page.evaluate(async ({ taskId, brunoId, carlaId }) => {
    const c = window.supabase.createClient(window.FLOWTASK_CONFIG.SUPABASE_URL, window.FLOWTASK_CONFIG.SUPABASE_ANON_KEY);
    const out = {};
    out.upd = (await c.from('tasks').update({ status: 'done' }).eq('id', taskId).select()).data.length;
    out.del = (await c.from('tasks').delete().eq('id', taskId).select()).data.length;
    out.promote = (await c.from('profiles').update({ role: 'admin' }).eq('id', brunoId).select()).error;
    out.assignOther = (await c.from('tasks').insert({ title: 'x', assignee_id: carlaId }).select()).error;
    out.forgeAuthor = (await c.from('tasks').insert({ title: 'forjada', created_by: carlaId }).select().maybeSingle()).data;
    out.edge = await (await fetch(window.FLOWTASK_CONFIG.SUPABASE_URL + '/functions/v1/admin-users', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + JSON.parse(localStorage.getItem(Object.keys(localStorage).find((k) => k.startsWith('fake-sb-session')))).access_token }, body: JSON.stringify({ action: 'create', email: 'hack@x.com', full_name: 'Hack', password: 'Senha-12345' }) })).json();
    return out;
  }, { taskId, brunoId, carlaId });
  eq(r.upd, 0, 'update em tarefa alheia deve afetar 0 linhas');
  eq(r.del, 0, 'delete deve afetar 0 linhas');
  ok(r.promote && r.promote.code === '42501', 'auto-promoção deve ser negada: ' + JSON.stringify(r.promote));
  ok(r.assignOther && r.assignOther.code === '42501', 'atribuir a outro deve ser negado: ' + JSON.stringify(r.assignOther));
  eq(r.forgeAuthor.created_by, brunoId, 'autor forjado deve ser sobrescrito pelo banco');
  ok(/administradores/i.test(r.edge.error || ''), 'Edge Function deve recusar não-admin: ' + JSON.stringify(r.edge));
  eq((await sql(`select count(*)::int as n from public.profiles where email='hack@x.com'`))[0].n, 0, 'usuário não pode ter sido criado');
  eq((await sql(`select role from public.profiles where email='bruno@teste.com'`))[0].role, 'member');
  eq((await sql(`select status from public.tasks where id='${taskId}'`))[0].status, 'todo', 'tarefa alheia intacta');
});

console.log('\n== Edição, exclusão, filtros ==');
await test('13 admin edita título/prioridade/responsável → outras sessões atualizam sozinhas', async () => {
  await cardIn(admin.page, 'todo', 'Prio média').locator('h4, button.font-semibold').first().click();
  await admin.page.fill('#task-title', 'Prio média (editada)');
  await admin.page.selectOption('#task-priority', 'high');
  await admin.page.selectOption('#task-assignee', { label: 'Carla Membro' });
  await admin.page.click('#btn-task-save');
  await admin.page.locator('#modal-task').waitFor({ state: 'hidden' });
  await waitFor(() => hasCard(carla.page, 'Prio média (editada)'), 'Carla ver título novo');
  await waitFor(async () => !(await hasCard(carla.page, 'Prio média') && !(await hasCard(carla.page, 'Prio média (editada)'))), 'sem versão antiga');
  const r = await sql(`select t.priority, p.full_name as resp, u.full_name as atualizado_por from public.tasks t join public.profiles p on p.id=t.assignee_id join public.profiles u on u.id=t.updated_by where t.title='Prio média (editada)'`);
  eq(r[0], { priority: 'high', resp: 'Carla Membro', atualizado_por: 'Ana Admin' });
});

await test('14 filtros: responsável, status, prioridade e prazo', async () => {
  const p = admin.page;
  const visibleTitles = async () => (await p.locator('[data-task-id] button.font-semibold, [data-task-id] h4').allTextContents()).sort();
  await p.selectOption('#f-user', { label: 'Bruno Membro' });
  eq(await visibleTitles(), ['Pauta da reunião', 'Revisar contrato'], 'filtro por responsável');
  await p.selectOption('#f-status', 'in_progress');
  eq(await visibleTitles(), ['Revisar contrato'], 'responsável + status');
  await p.click('#btn-clear-filters');
  await p.selectOption('#f-priority', 'high');
  eq(await visibleTitles(), ['Prio média (editada)', 'Revisar contrato'], 'filtro por prioridade');
  await p.click('#btn-clear-filters');
  await p.fill('#f-start', D(15)); await p.fill('#f-end', D(25));
  await p.dispatchEvent('#f-end', 'change');
  eq(await visibleTitles(), ['Revisar contrato'], 'filtro por prazo (só a tarefa com prazo no intervalo)');
  await p.click('#btn-clear-filters');
  await p.selectOption('#f-user', 'none');
  eq((await visibleTitles()).includes('Revisar contrato'), false, 'sem responsável não inclui tarefa atribuída');
  await p.click('#btn-clear-filters');
  ok((await visibleTitles()).length >= 4, 'limpar filtros mostra tudo');
});

await test('15 admin exclui tarefa → some das duas sessões e do banco; membro não vê botão Excluir', async () => {
  await createTask(admin.page, { title: 'Apagar-me' });
  await waitFor(() => hasCard(bruno.page, 'Apagar-me'), 'Bruno ver a tarefa');
  await cardIn(bruno.page, 'todo', 'Apagar-me').locator('h4, button.font-semibold').first().click();
  ok(await bruno.page.locator('#btn-task-delete').isHidden(), 'membro sem Excluir');
  await bruno.page.click('[data-close="modal-task"]');
  await cardIn(admin.page, 'todo', 'Apagar-me').locator('h4, button.font-semibold').first().click();
  await admin.page.click('#btn-task-delete');
  await admin.page.locator('#modal-task').waitFor({ state: 'hidden' });
  await waitFor(async () => !(await hasCard(bruno.page, 'Apagar-me')), 'tarefa sumir para o Bruno');
  eq((await sql(`select count(*)::int n from public.tasks where title='Apagar-me'`))[0].n, 0);
});

console.log('\n== Segurança de conteúdo (XSS) e CSV ==');
await test('16 XSS: HTML/script em título e descrição aparece como TEXTO e nunca executa (nas duas sessões)', async () => {
  await createTask(admin.page, { title: '<img src=x onerror="window.__xss=1"> <b>negrito</b>', desc: '<script>window.__xss=2</script><svg onload="window.__xss=3">', priority: 'low' });
  await waitFor(() => hasCard(bruno.page, '<b>negrito</b>'), 'Bruno ver a tarefa (texto literal)');
  for (const u of [admin, bruno]) {
    await new Promise((r) => setTimeout(r, 400));
    eq(await u.page.evaluate(() => window.__xss), undefined, `${u.name}: script não pode ter executado`);
    eq(await u.page.locator('[data-task-id] img[src="x"]').count(), 0, 'nenhuma <img> injetada');
    eq(await u.page.locator('[data-task-id] b').count(), 0, 'nenhum <b> injetado');
  }
  await admin.page.click('nav[aria-label="Navegação principal"] [data-tab="calendar"]');
  await admin.page.click('nav[aria-label="Navegação principal"] [data-tab="kanban"]');
});

await test('17 exportação CSV: BOM, escape de aspas/vírgulas/quebras de linha e proteção contra fórmulas', async () => {
  await createTask(admin.page, { title: 'Tarefa "com aspas", vírgula', desc: 'linha 1\nlinha 2; ponto-e-vírgula', priority: 'medium', due: D(10) });
  await createTask(admin.page, { title: '=HYPERLINK("http://evil","clique")', desc: '@SUM(1+1)', priority: 'low' });
  await admin.page.click('#btn-export');
  await admin.page.selectOption('#export-type', 'all_tasks');
  await admin.page.selectOption('#export-sep', ',');
  const [dl] = await Promise.all([admin.page.waitForEvent('download'), admin.page.click('#form-export button[type=submit]')]);
  const file = path.join(OUT, 'export.csv'); await dl.saveAs(file);
  const raw = fs.readFileSync(file, 'utf8');
  ok(raw.charCodeAt(0) === 0xFEFF, 'BOM UTF-8 no início (Excel abre com acentos corretos)');
  const rows = parseCsv(raw.slice(1), ',');
  eq(rows[0].slice(0, 7), ['ID', 'Título', 'Descrição', 'Prioridade', 'Status', 'Prazo', 'Responsável']);
  const find = (needle) => rows.find((r) => (r[1] || '').includes(needle));
  const r1 = find('com aspas');
  eq(r1[1], 'Tarefa "com aspas", vírgula', 'aspas e vírgula preservadas');
  eq(r1[2], 'linha 1\nlinha 2; ponto-e-vírgula', 'quebra de linha preservada');
  eq(r1[3], 'Média'); eq(r1[5], `${D(10).split('-').reverse().join('/')}`, 'prazo no formato dd/mm/aaaa');
  eq(find('HYPERLINK')[1], `'=HYPERLINK("http://evil","clique")`, 'fórmula neutralizada com apóstrofo');
  eq(find('HYPERLINK')[2], `'@SUM(1+1)`);
  ok(rows.every((r) => r.length === rows[0].length), 'todas as linhas com o mesmo número de colunas');
  // filtro "apenas concluídas" + separador ;
  await admin.page.click('#btn-export');
  await admin.page.selectOption('#export-type', 'done_tasks');
  await admin.page.selectOption('#export-sep', ';');
  const [dl2] = await Promise.all([admin.page.waitForEvent('download'), admin.page.click('#form-export button[type=submit]')]);
  const f2 = path.join(OUT, 'export_done.csv'); await dl2.saveAs(f2);
  const rows2 = parseCsv(fs.readFileSync(f2, 'utf8').slice(1), ';');
  eq(rows2.slice(1).map((r) => r[1]), ['Prio baixa'], 'só concluídas');
});

console.log('\n== Gestão de usuários (Edge Function real) ==');
await test('18 admin cadastra usuário com senha temporária → aparece na Equipe de todos', async () => {
  await admin.page.click('nav[aria-label="Navegação principal"] [data-tab="users"]');
  await admin.page.fill('#uc-name', 'Diego <i>Novo</i>');
  await admin.page.fill('#uc-email', 'diego@teste.com');
  await admin.page.fill('#uc-title', 'Estagiário');
  await admin.page.fill('#uc-pass', 'Temp-12345');
  await admin.page.click('#btn-user-create');
  await waitFor(async () => (await admin.page.locator('#users-list').textContent()).includes('Diego <i>Novo</i>'), 'Diego na lista (texto literal)');
  eq(await admin.page.locator('#users-list i').count(), 0, 'sem HTML injetado no nome');
  const r = await sql(`select role, must_change_password, job_title from public.profiles where email='diego@teste.com'`);
  eq(r[0], { role: 'member', must_change_password: true, job_title: 'Estagiário' });
  await bruno.page.click('nav[aria-label="Navegação principal"] [data-tab="users"]');
  await waitFor(async () => (await bruno.page.locator('#users-list').textContent()).includes('diego@teste.com'), 'Bruno ver Diego em tempo real');
  await bruno.page.click('nav[aria-label="Navegação principal"] [data-tab="kanban"]');
});

await test('19 e-mail duplicado é recusado com mensagem clara', async () => {
  await admin.page.fill('#uc-name', 'Outro Diego');
  await admin.page.fill('#uc-email', 'diego@teste.com');
  await admin.page.fill('#uc-pass', 'Temp-12345');
  await admin.page.click('#btn-user-create');
  await waitFor(async () => /Já existe um usuário/.test(await admin.page.locator('#toasts').textContent()), 'toast de duplicado');
  await admin.page.click('#uc-name', { clickCount: 3 }).catch(() => {});
});

const diego = await newUser('Diego(novo)');
await test('20 novo usuário é OBRIGADO a trocar a senha temporária no 1º acesso', async () => {
  await login(diego.page, 'diego@teste.com', 'Temp-12345');
  await diego.page.locator('#form-newpass').waitFor({ state: 'visible', timeout: 8000 });
  ok(!(await visible(diego.page, '#screen-app')), 'não entra no app antes de trocar');
  await diego.page.fill('#newpass-1', 'Nova-Senha-9'); await diego.page.fill('#newpass-2', 'Outra-Coisa-9');
  await diego.page.click('#btn-newpass');
  await waitFor(async () => /não coincidem/.test(await diego.page.locator('#auth-message').textContent()), 'aviso de senhas diferentes');
  await diego.page.fill('#newpass-2', 'Nova-Senha-9');
  await diego.page.click('#btn-newpass');
  await diego.page.locator('#screen-app').waitFor({ state: 'visible', timeout: 8000 });
  eq((await sql(`select must_change_password m from public.profiles where email='diego@teste.com'`))[0].m, false);
  await diego.page.click('#btn-logout');
  await diego.page.locator('#login-email').waitFor({ state: 'visible' });
  await diego.page.fill('#login-email', 'diego@teste.com'); await diego.page.fill('#login-password', 'Temp-12345'); await diego.page.click('#btn-login');
  await waitFor(async () => /incorretos/.test(await diego.page.locator('#auth-message').textContent()), 'senha antiga deve falhar');
  await diego.page.fill('#login-password', 'Nova-Senha-9'); await diego.page.click('#btn-login');
  await diego.page.locator('#screen-app').waitFor({ state: 'visible', timeout: 8000 });
});

await test('21 admin altera nível de acesso (Diego → Administrador → Membro)', async () => {
  const row = () => admin.page.locator('#users-list > div', { hasText: 'diego@teste.com' });
  await row().locator('select').selectOption('admin');
  await waitFor(async () => (await sql(`select role from public.profiles where email='diego@teste.com'`))[0].role === 'admin', 'Diego admin no banco');
  await waitFor(async () => /Administrador/.test(await diego.page.locator('#me-role').textContent()), 'Diego ver o novo nível sem recarregar');
  await row().locator('select').selectOption('member');
  await waitFor(async () => (await sql(`select role from public.profiles where email='diego@teste.com'`))[0].role === 'member', 'Diego volta a membro');
});

await test('22 admin redefine a senha de outro usuário (nova temporária, troca obrigatória)', async () => {
  promptValue = 'Reset-54321';
  await admin.page.locator('#users-list > div', { hasText: 'diego@teste.com' }).getByText('Redefinir senha').click();
  await waitFor(async () => (await sql(`select must_change_password m from public.profiles where email='diego@teste.com'`))[0].m === true, 'flag must_change_password');
});

await test('23 admin desativa usuário → sessão aberta é encerrada e novo login é recusado; reativar libera', async () => {
  await admin.page.locator('#users-list > div', { hasText: 'carla@teste.com' }).getByText('Desativar').click();
  await waitFor(() => visible(carla.page, '#screen-auth'), 'Carla ser deslogada em tempo real');
  await waitFor(async () => /desativad/.test(await carla.page.locator('#auth-message').textContent()), 'mensagem de conta desativada');
  eq((await sql(`select is_active a from public.profiles where email='carla@teste.com'`))[0].a, false);
  await login(carla.page, 'carla@teste.com', 'Senha-Carla-1');
  await waitFor(async () => /desativada/.test(await carla.page.locator('#auth-message').textContent()), 'login recusado');
  ok(!(await visible(carla.page, '#screen-app')));
  await admin.page.locator('#users-list > div', { hasText: 'carla@teste.com' }).getByText('Reativar').click();
  await waitFor(async () => (await sql(`select is_active a from public.profiles where email='carla@teste.com'`))[0].a === true, 'reativada');
  await login(carla.page, 'carla@teste.com', 'Senha-Carla-1');
  await carla.page.locator('#screen-app').waitFor({ state: 'visible', timeout: 8000 });
});

await test('24 o último administrador ativo não pode ser desativado/rebaixado (regra do banco)', async () => {
  const r = await admin.page.evaluate(async () => {
    const c = window.supabase.createClient(window.FLOWTASK_CONFIG.SUPABASE_URL, window.FLOWTASK_CONFIG.SUPABASE_ANON_KEY);
    const me = JSON.parse(localStorage.getItem(Object.keys(localStorage).find((k) => k.startsWith('fake-sb-session')))).user.id;
    return (await c.from('profiles').update({ role: 'member' }).eq('id', me).select()).error;
  });
  ok(r && /pelo menos um administrador/.test(r.message), 'deveria recusar: ' + JSON.stringify(r));
});

await test('25 recuperação de senha: resposta neutra (não revela se o e-mail existe)', async () => {
  const p = carla.page;
  await p.click('#btn-logout'); await p.locator('#login-email').waitFor({ state: 'visible' });
  await p.click('#link-forgot');
  await p.fill('#forgot-email', 'naoexiste@teste.com'); await p.click('#btn-forgot');
  await waitFor(async () => /Se o e-mail estiver cadastrado/.test(await p.locator('#auth-message').textContent()), 'mensagem neutra');
  eq((await state()).resetEmails, ['naoexiste@teste.com'], 'pedido enviado ao Auth');
});

console.log('\n== Persistência, abas e responsividade ==');
await test('26 dados continuam após sair e entrar de novo; logout limpa a tela e a sessão', async () => {
  const p = admin.page;
  await p.click('nav[aria-label="Navegação principal"] [data-tab="kanban"]');
  const before = (await sql(`select count(*)::int n from public.tasks`))[0].n;
  await p.click('#btn-logout');
  await p.locator('#login-email').waitFor({ state: 'visible' });
  eq(await p.locator('#col-todo').innerHTML(), '', 'DOM limpo após logout');
  await p.reload();
  await p.locator('#login-email').waitFor({ state: 'visible' });
  ok(!(await visible(p, '#screen-app')), 'continua deslogado após reload');
  await loginOk(admin, 'ana@teste.com', 'Senha-Admin-1');
  await waitFor(async () => (await p.locator('[data-task-id]').count()) === before, `todas as ${before} tarefas de volta`);
});

await test('27 abas Calendário e Estatísticas mostram os dados', async () => {
  const p = admin.page;
  await p.click('nav[aria-label="Navegação principal"] [data-tab="calendar"]');
  ok(/\d{4}/.test(await p.locator('#calendar-month-year').textContent()));
  ok((await p.locator('#calendar-grid', { hasText: 'Revisar contrato' }).count()) === 1, 'tarefa no dia do prazo');
  await p.click('nav[aria-label="Navegação principal"] [data-tab="stats"]');
  const total = Number(await p.locator('#stat-total').textContent());
  eq(total, (await sql(`select count(*)::int n from public.tasks`))[0].n, 'total de tarefas');
  ok(/%$/.test(await p.locator('#stat-rate').textContent()));
  await p.click('nav[aria-label="Navegação principal"] [data-tab="kanban"]');
});

await test('28 celular (390×844): navegação inferior, usuário visível, sem rolagem horizontal', async () => {
  const m = await newUser('Ana(mobile)', { width: 390, height: 844 });
  await loginOk(m, 'ana@teste.com', 'Senha-Admin-1');
  ok(await visible(m.page, 'nav[aria-label="Navegação"]'), 'barra inferior visível');
  ok(await visible(m.page, '#me-name-m'), 'usuário visível no celular');
  ok(/Administrador/.test(await m.page.locator('#me-role-m').textContent()), 'nível visível no celular');
  const over = await m.page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  ok(over <= 1, `rolagem horizontal de ${over}px`);
  await m.page.screenshot({ path: path.join(OUT, 'mobile-kanban.png'), fullPage: false });
  await m.page.click('nav[aria-label="Navegação"] [data-tab="calendar"]');
  await m.page.screenshot({ path: path.join(OUT, 'mobile-calendar.png') });
  await m.ctx.close();
});

await test('29 sem violações de CSP, sem erros de console/página, sem requisições falhas', async () => {
  for (const u of [admin, bruno, carla, diego]) {
    const csp = await u.page.evaluate(() => window.__csp);
    if (csp.length) problems.push(`${u.name} CSP: ${csp.join(' | ')}`);
  }
  ok(problems.length === 0, problems.slice(0, 5).join(' || '));
});

// desktop screenshots para inspeção visual
await admin.page.click('nav[aria-label="Navegação principal"] [data-tab="kanban"]');
await admin.page.screenshot({ path: path.join(OUT, 'desktop-kanban.png') });
await bruno.page.screenshot({ path: path.join(OUT, 'desktop-kanban-membro.png') });

// ------------------------------------------------------------------ resumo
await browser.close();
backend.kill();
const failed = results.filter((r) => !r.ok);
console.log(`\n=== ${results.length - failed.length}/${results.length} testes passaram ===`);
if (handled.length) console.log(`(erros TRATADOS e registrados de propósito pelo app durante testes negativos: ${handled.length})`);
if (problems.length) console.log('Problemas de console/CSP:\n - ' + problems.join('\n - '));
fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ results, problems, handledCount: handled.length }, null, 2));
process.exit(failed.length ? 1 : 0);
