/* CLIENTE SUPABASE SIMULADO — só para os testes (tests/e2e). Em produção o build copia a biblioteca oficial
 * para vendor/supabase.js. Aqui imitamos apenas a parte da API que o app.js usa:
 *   auth.{onAuthStateChange,getSession,signInWithPassword,signOut,updateUser,resetPasswordForEmail}
 *   from(tabela).{select,insert,update,delete,eq,order,maybeSingle}
 *   channel().on('postgres_changes').subscribe(), removeChannel(), functions.invoke()
 * As chamadas vão para tests/e2e/backend.mjs (Postgres real por trás).
 */
(function () {
  'use strict';
  window.supabase = {
    createClient(url) {
      const KEY = 'fake-sb-session:' + url;
      const listeners = new Set();
      const readSession = () => { try { return JSON.parse(localStorage.getItem(KEY)); } catch (_) { return null; } };
      const emit = (event, session) => listeners.forEach((cb) => { try { cb(event, session); } catch (e) { console.error(e); } });
      const token = () => (readSession() || {}).access_token || '';
      const post = (path, body, auth) => fetch(url + path, {
        method: 'POST', headers: { 'Content-Type': 'application/json', ...(auth ? { Authorization: 'Bearer ' + token() } : {}) }, body: JSON.stringify(body),
      });

      const auth = {
        onAuthStateChange(cb) {
          listeners.add(cb);
          setTimeout(() => cb('INITIAL_SESSION', readSession()), 0); // igual à biblioteca real
          return { data: { subscription: { unsubscribe: () => listeners.delete(cb) } } };
        },
        async getSession() { return { data: { session: readSession() }, error: null }; },
        async signInWithPassword({ email, password }) {
          const r = await post('/auth/signin', { email, password });
          const j = await r.json();
          if (!r.ok) return { data: { session: null, user: null }, error: Object.assign(new Error(j.message), { status: r.status }) };
          const session = { access_token: j.access_token, user: j.user };
          localStorage.setItem(KEY, JSON.stringify(session));
          emit('SIGNED_IN', session);
          return { data: { session, user: j.user }, error: null };
        },
        async signOut() { localStorage.removeItem(KEY); emit('SIGNED_OUT', null); return { error: null }; },
        async updateUser({ password }) {
          const r = await post('/auth/update', { password }, true);
          const j = await r.json();
          if (!r.ok) return { data: null, error: Object.assign(new Error(j.message), { status: r.status }) };
          emit('USER_UPDATED', readSession());
          return { data: { user: (readSession() || {}).user }, error: null };
        },
        async resetPasswordForEmail(email) { await post('/auth/reset', { email }); return { data: {}, error: null }; },
      };

      function from(table) {
        const spec = { table, op: 'select', filters: [] };
        let single = false;
        const b = {
          select() { return b; },
          insert(values) { spec.op = 'insert'; spec.values = values; return b; },
          update(patch) { spec.op = 'update'; spec.patch = patch; return b; },
          delete() { spec.op = 'delete'; return b; },
          eq(c, v) { spec.filters.push({ col: c, val: v }); return b; },
          order(c, o) { spec.order = { col: c, asc: !o || o.ascending !== false }; return b; },
          maybeSingle() { single = true; return b; },
          then(res, rej) { return run().then(res, rej); },
        };
        async function run() {
          const r = await post('/rest', spec, true);
          const j = await r.json();
          if (!r.ok) return { data: null, error: { message: j.message, code: j.code } };
          return { data: single ? (j[0] ?? null) : j, error: null };
        }
        return b;
      }

      function channel() {
        const handlers = [];
        let es = null;
        const ch = {
          on(type, filter, cb) { handlers.push({ filter, cb }); return ch; },
          subscribe(statusCb) {
            es = new EventSource(url + '/events?token=' + encodeURIComponent(token()));
            es.onopen = () => statusCb && statusCb('SUBSCRIBED');
            es.onerror = () => statusCb && statusCb('CHANNEL_ERROR');
            es.onmessage = (m) => {
              const p = JSON.parse(m.data);
              handlers.forEach((h) => { if (h.filter.table === p.table && (h.filter.event === '*' || h.filter.event === p.eventType)) h.cb(p); });
            };
            return ch;
          },
          _close() { if (es) es.close(); },
        };
        return ch;
      }

      return {
        auth, from, channel,
        removeChannel(ch) { ch._close(); },
        functions: {
          async invoke(name, { body }) {
            const r = await fetch(url + '/functions/v1/' + name, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token() }, body: JSON.stringify(body) });
            if (!r.ok) return { data: null, error: Object.assign(new Error('Edge Function returned a non-2xx status code'), { context: r }) };
            return { data: await r.json(), error: null };
          },
        },
      };
    },
  };
})();
