#!/usr/bin/env bash
# Roda schema.sql + testes de RLS num PostgreSQL local DESCARTÁVEL.
# Precisa de PGHOST/PGPORT/PGUSER apontando para um Postgres de testes (nunca o de produção).
# Sai com código != 0 se: o schema der erro, algum teste falhar, ou algum teste não registrar resultado.
set -euo pipefail
cd "$(dirname "$0")/.."
DB=${1:-ft_test}

psql -qX -c "drop database if exists $DB" -c "create database $DB" >/dev/null 2>&1
psql -d "$DB" -qX -v ON_ERROR_STOP=1 -f tests/sql/00_supabase_shim.sql -f supabase/schema.sql >/dev/null 2>&1 \
  || { echo "ERRO: schema.sql falhou"; psql -d "$DB" -qX -v ON_ERROR_STOP=1 -f supabase/schema.sql 2>&1 | grep -i error | head; exit 1; }

# o schema precisa ser reexecutável sem erro
psql -d "$DB" -qX -v ON_ERROR_STOP=1 -f supabase/schema.sql >/dev/null 2>&1 \
  || { echo "ERRO: schema.sql não é idempotente"; exit 1; }

OUT=$(psql -d "$DB" -qX -f tests/sql/10_rls_tests.sql 2>&1)
ERRS=$(echo "$OUT" | grep -E "^psql:.*ERROR" || true)
echo "$OUT" | sed -n '/===== RESULTADOS/,$p'

EXPECTED=$(grep -cE "^select test\.(ok|fails|rows|eq)\(" tests/sql/10_rls_tests.sql)
GOT=$(psql -d "$DB" -qAtX -c "select count(*) from test.results")
FAILED=$(psql -d "$DB" -qAtX -c "select count(*) from test.results where not ok")

echo
echo "chamadas de teste no arquivo: $EXPECTED | resultados registrados: $GOT | falhas: $FAILED"
[ -z "$ERRS" ] || { echo "ERROS SQL durante os testes:"; echo "$ERRS"; exit 1; }
[ "$EXPECTED" = "$GOT" ] || { echo "ERRO: nem todos os testes registraram resultado"; exit 1; }
[ "$FAILED" = "0" ] || { echo "ERRO: há testes falhando"; exit 1; }
echo "OK: todos os testes de banco passaram"
