// Testes unitários da Edge Function (sem banco, sem rede): ramos de validação e autorização.
//   tsx tests/edge_unit.mjs
import { makeHandler } from '../supabase/functions/admin-users/handler.ts';

let pass = 0, fail = 0;
const t = async (name, fn) => { try { await fn(); pass++; console.log('  PASS', name); } catch (e) { fail++; console.log('  FAIL', name, '→', e.message); } };
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${m || ''} obtido=${JSON.stringify(a)} esperado=${JSON.stringify(b)}`); };

const ADMIN = '11111111-1111-4111-8111-111111111111';
const MEMBER = '22222222-2222-4222-8222-222222222222';
const calls = [];
let who = null; // chamador atual (compartilhado entre o cliente "anon" e o cliente "service")

// "Supabase" de mentira: token "admin"/"member"/"inactive" identifica o chamador
function fakeClient(url, key) {
  const profiles = { admin: { role: 'admin', is_active: true }, member: { role: 'member', is_active: true }, inactive: { role: 'admin', is_active: false } };
  const q = { _id: null, select: () => q, eq: (c, v) => { q._id = v; return q; }, update: (p) => { calls.push(['update', p]); return { eq: async () => ({ error: null }) }; },
    maybeSingle: async () => ({ data: profiles[who] ?? null, error: null }) };
  return {
    from: () => q,
    auth: {
      getUser: async (jwt) => { if (!profiles[jwt]) return { data: { user: null }, error: { message: 'bad' } }; who = jwt; return { data: { user: { id: jwt === 'member' ? MEMBER : ADMIN } }, error: null }; },
      admin: {
        createUser: async (a) => { calls.push(['createUser', a.email]); return { data: { user: { id: '33333333-3333-4333-8333-333333333333' } }, error: null }; },
        inviteUserByEmail: async (e) => { calls.push(['invite', e]); return { data: { user: { id: '33333333-3333-4333-8333-333333333333' } }, error: null }; },
        updateUserById: async () => ({ error: null }), deleteUser: async () => ({ error: null }),
      },
    },
  };
}
const mk = (env = {}) => makeHandler({ createClient: fakeClient, env: (k) => ({ SUPABASE_URL: 'http://x', SUPABASE_ANON_KEY: 'a', SUPABASE_SERVICE_ROLE_KEY: 's', ...env }[k]) });
const call = (h, { method = 'POST', token, body, raw } = {}) =>
  h(new Request('http://x/fn', { method, headers: { 'content-type': 'application/json', ...(token ? { authorization: 'Bearer ' + token } : {}) }, body: method === 'GET' ? undefined : (raw ?? JSON.stringify(body)) }));
const good = { action: 'create', email: 'novo@escritorio.com.br', password: 'Senha-12345', full_name: 'Novo' };

console.log('== Edge Function admin-users (unitários) ==');
const h = mk();
await t('OPTIONS responde 204 com CORS', async () => { const r = await call(h, { method: 'OPTIONS' }); eq(r.status, 204); });
await t('GET é recusado (405)', async () => eq((await call(h, { method: 'GET', token: 'admin' })).status, 405));
await t('sem token → 401', async () => eq((await call(h, { body: good })).status, 401));
await t('token inválido → 401', async () => eq((await call(h, { token: 'lixo', body: good })).status, 401));
await t('membro → 403 e nada é criado', async () => { calls.length = 0; eq((await call(h, { token: 'member', body: good })).status, 403); eq(calls.length, 0, 'nenhuma escrita'); });
await t('admin INATIVO → 403', async () => eq((await call(h, { token: 'inactive', body: good })).status, 403));
await t('JSON inválido → 400', async () => eq((await call(h, { token: 'admin', raw: '{nao-json' })).status, 400));
await t('corpo gigante → 413', async () => eq((await call(h, { token: 'admin', raw: JSON.stringify({ x: 'a'.repeat(20000) }) })).status, 413));
await t('ação desconhecida → 400', async () => eq((await call(h, { token: 'admin', body: { action: 'drop_database' } })).status, 400));
await t('e-mail inválido → 400', async () => eq((await call(h, { token: 'admin', body: { ...good, email: 'sem-arroba' } })).status, 400));
await t('senha curta → 400', async () => eq((await call(h, { token: 'admin', body: { ...good, password: '123' } })).status, 400));
await t('nome vazio → 400', async () => eq((await call(h, { token: 'admin', body: { ...good, full_name: '  ' } })).status, 400));
await t('admin cria usuário válido → 200 (papel padrão = membro)', async () => {
  calls.length = 0;
  const r = await call(h, { token: 'admin', body: good }); eq(r.status, 200);
  eq(calls.find((c) => c[0] === 'update')[1].role, 'member');
});
await t('papel só aceita "admin"; qualquer outro valor vira membro', async () => {
  calls.length = 0; await call(h, { token: 'admin', body: { ...good, role: 'superuser' } });
  eq(calls.find((c) => c[0] === 'update')[1].role, 'member');
});
await t('admin não pode se desativar / redefinir a própria senha por aqui → 400', async () => {
  eq((await call(h, { token: 'admin', body: { action: 'set_active', user_id: ADMIN, active: false } })).status, 400);
  eq((await call(h, { token: 'admin', body: { action: 'reset_password', user_id: ADMIN, password: 'Senha-12345' } })).status, 400);
});
await t('user_id que não é UUID → 400', async () => eq((await call(h, { token: 'admin', body: { action: 'set_active', user_id: "1' or 1=1", active: false } })).status, 400));
await t('restrição de domínio (ALLOWED_EMAIL_DOMAIN) recusa e-mail de fora', async () => {
  const hd = mk({ ALLOWED_EMAIL_DOMAIN: '@escritorio.com.br' });
  eq((await call(hd, { token: 'admin', body: { ...good, email: 'x@gmail.com' } })).status, 400);
  eq((await call(hd, { token: 'admin', body: good })).status, 200);
});
await t('ALLOWED_ORIGIN restringe o CORS', async () => {
  const ho = mk({ ALLOWED_ORIGIN: 'https://flow.pages.dev' });
  const r = await ho(new Request('http://x/fn', { method: 'OPTIONS', headers: { origin: 'https://evil.com' } }));
  eq(r.headers.get('access-control-allow-origin'), 'https://flow.pages.dev');
});
await t('convite por e-mail → 200', async () => eq((await call(h, { token: 'admin', body: { action: 'invite', email: 'conv@escritorio.com.br', full_name: 'Convidado' } })).status, 200));

console.log(`\n${pass}/${pass + fail} testes unitários passaram`);
process.exit(fail ? 1 : 0);
