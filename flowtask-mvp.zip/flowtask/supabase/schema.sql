-- =====================================================================
-- FlowTask — esquema do banco de dados (Supabase / PostgreSQL)
-- =====================================================================
-- Como usar: Supabase Dashboard → SQL Editor → New query → cole TUDO → Run.
-- O script pode ser executado mais de uma vez sem quebrar o que já existe.
--
-- Modelo de permissões
--   admin  : vê tudo, cria/edita/exclui qualquer tarefa, atribui responsáveis,
--            altera prioridades, gerencia usuários (papel, ativo/inativo).
--   member : vê todas as tarefas, cria tarefas (sem atribuir a outra pessoa),
--            edita tarefas que criou OU que foram atribuídas a ele
--            (título, descrição, prazo, status). Só o criador altera a
--            prioridade; só admin altera o responsável e exclui.
--   inativo: qualquer usuário com is_active = false perde todo o acesso.
-- Tudo isso é imposto AQUI, no banco, e não apenas escondido na interface.
-- =====================================================================


-- ---------------------------------------------------------------------
-- 1. TABELAS
-- ---------------------------------------------------------------------

create table if not exists public.profiles (
  id                   uuid primary key references auth.users (id) on delete cascade,
  email                text        not null,
  full_name            text        not null default '',
  job_title            text        not null default '',
  role                 text        not null default 'member'
                                   check (role in ('admin', 'member')),
  is_active            boolean     not null default true,
  must_change_password boolean     not null default false,
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now(),
  constraint profiles_full_name_len check (char_length(full_name) <= 120),
  constraint profiles_job_title_len check (char_length(job_title) <= 120)
);

create table if not exists public.tasks (
  id          uuid primary key default gen_random_uuid(),
  title       text        not null,
  description text        not null default '',
  priority    text        not null default 'medium'
                          check (priority in ('low', 'medium', 'high')),
  status      text        not null default 'todo'
                          check (status in ('todo', 'in_progress', 'done')),
  assignee_id uuid        references public.profiles (id) on delete set null,
  due_date    date,
  created_by  uuid        references public.profiles (id) on delete set null,
  created_at  timestamptz not null default now(),
  updated_by  uuid        references public.profiles (id) on delete set null,
  updated_at  timestamptz not null default now(),
  constraint tasks_title_len check (char_length(btrim(title)) between 1 and 200),
  constraint tasks_desc_len  check (char_length(description) <= 2000)
);

create index if not exists tasks_status_idx     on public.tasks (status);
create index if not exists tasks_assignee_idx   on public.tasks (assignee_id);
create index if not exists tasks_due_date_idx   on public.tasks (due_date);
create index if not exists tasks_created_by_idx on public.tasks (created_by);
create index if not exists tasks_updated_by_idx on public.tasks (updated_by);


-- ---------------------------------------------------------------------
-- 2. FUNÇÕES AUXILIARES (SECURITY DEFINER para evitar recursão de RLS)
-- ---------------------------------------------------------------------

create or replace function public.app_is_active()
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.is_active
  );
$$;

create or replace function public.app_is_admin()
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.is_active and p.role = 'admin'
  );
$$;

revoke all on function public.app_is_active() from public, anon;
revoke all on function public.app_is_admin()  from public, anon;
grant execute on function public.app_is_active() to authenticated, service_role;
grant execute on function public.app_is_admin()  to authenticated, service_role;


-- ---------------------------------------------------------------------
-- 3. PERFIL AUTOMÁTICO PARA CADA USUÁRIO DO SUPABASE AUTH
--    IMPORTANTE: o papel NUNCA vem dos metadados do usuário (eles podem
--    ser editados pelo próprio usuário). Todo usuário novo nasce 'member'.
-- ---------------------------------------------------------------------

create or replace function public.handle_new_user()
returns trigger
language plpgsql security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (
    new.id,
    coalesce(new.email, ''),
    left(
      coalesce(
        nullif(btrim(new.raw_user_meta_data ->> 'full_name'), ''),
        split_part(coalesce(new.email, ''), '@', 1)
      ),
      120
    )
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.handle_user_email_change()
returns trigger
language plpgsql security definer
set search_path = ''
as $$
begin
  if new.email is distinct from old.email then
    update public.profiles set email = coalesce(new.email, '') where id = new.id;
  end if;
  return new;
end;
$$;

drop trigger if exists on_auth_user_email_changed on auth.users;
create trigger on_auth_user_email_changed
  after update of email on auth.users
  for each row execute function public.handle_user_email_change();


-- ---------------------------------------------------------------------
-- 4. TRIGGERS DE PROTEÇÃO (regras que o RLS sozinho não consegue expressar)
--    "Privilegiado" = conexão que NÃO é authenticated/anon (SQL Editor,
--    service_role, funções internas do Supabase). Usuários vindos da API
--    sempre rodam como 'authenticated'.
-- ---------------------------------------------------------------------

create or replace function public.profiles_guard()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  if tg_op = 'UPDATE' then
    new.updated_at := now();
  end if;

  if current_user in ('authenticated', 'anon') then
    if tg_op = 'INSERT' then
      raise exception 'Perfis são criados automaticamente' using errcode = '42501';
    end if;

    -- ninguém, via API, muda identidade, e-mail ou data de criação
    if new.id is distinct from old.id
       or new.email is distinct from old.email
       or new.created_at is distinct from old.created_at then
      raise exception 'Campo protegido' using errcode = '42501';
    end if;

    if not public.app_is_admin() then
      -- membro: só nome, cargo e (apenas para limpar) must_change_password
      if new.role is distinct from old.role
         or new.is_active is distinct from old.is_active then
        raise exception 'Somente administradores podem alterar papel ou status do usuário'
          using errcode = '42501';
      end if;
      if new.must_change_password and not old.must_change_password then
        raise exception 'Operação não permitida' using errcode = '42501';
      end if;
    end if;
  end if;

  -- o sistema nunca pode ficar sem um administrador ativo
  if tg_op = 'UPDATE' and old.role = 'admin' and old.is_active
     and (new.role <> 'admin' or not new.is_active) then
    if not exists (
      select 1 from public.profiles p
      where p.id <> old.id and p.role = 'admin' and p.is_active
    ) then
      raise exception 'Deve existir pelo menos um administrador ativo'
        using errcode = 'P0001';
    end if;
  end if;

  return new;
end;
$$;

drop trigger if exists profiles_guard_trg on public.profiles;
create trigger profiles_guard_trg
  before insert or update on public.profiles
  for each row execute function public.profiles_guard();


create or replace function public.tasks_guard()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.title := btrim(new.title);

  if tg_op = 'INSERT' then
    new.created_at := now();
    new.updated_at := now();
    if current_user in ('authenticated', 'anon') then
      -- impede forjar o autor
      new.created_by := auth.uid();
      new.updated_by := auth.uid();
    end if;
    return new;
  end if;

  -- UPDATE
  new.updated_at := now();
  if current_user in ('authenticated', 'anon') then
    new.created_by := old.created_by;
    new.created_at := old.created_at;
    new.updated_by := auth.uid();

    if not public.app_is_admin() then
      if new.assignee_id is distinct from old.assignee_id then
        raise exception 'Somente administradores podem alterar o responsável'
          using errcode = '42501';
      end if;
      if new.priority is distinct from old.priority
         and old.created_by is distinct from auth.uid() then
        raise exception 'Somente o criador da tarefa ou um administrador pode alterar a prioridade'
          using errcode = '42501';
      end if;
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists tasks_guard_trg on public.tasks;
create trigger tasks_guard_trg
  before insert or update on public.tasks
  for each row execute function public.tasks_guard();


-- ---------------------------------------------------------------------
-- 5. ROW LEVEL SECURITY
-- ---------------------------------------------------------------------

alter table public.profiles enable row level security;
alter table public.tasks    enable row level security;

-- Privilégios de tabela (camada extra além do RLS)
revoke all on public.profiles from anon, authenticated;
revoke all on public.tasks    from anon, authenticated;
grant select on public.profiles to authenticated;
grant update (full_name, job_title, role, is_active, must_change_password)
  on public.profiles to authenticated;
grant select, insert, update, delete on public.tasks to authenticated;
grant all on public.profiles to service_role;
grant all on public.tasks    to service_role;

-- ---- profiles
drop policy if exists profiles_select        on public.profiles;
drop policy if exists profiles_update_self   on public.profiles;
drop policy if exists profiles_update_admin  on public.profiles;

-- Usuários ativos veem a equipe; qualquer um vê o próprio perfil
-- (para a interface poder avisar "conta desativada").
create policy profiles_select on public.profiles
  for select to authenticated
  using (id = auth.uid() or public.app_is_active());

create policy profiles_update_self on public.profiles
  for update to authenticated
  using (id = auth.uid() and public.app_is_active())
  with check (id = auth.uid());

create policy profiles_update_admin on public.profiles
  for update to authenticated
  using (public.app_is_admin())
  with check (public.app_is_admin());

-- (sem policy de INSERT/DELETE: perfis nascem pelo trigger e somem em cascata)

-- ---- tasks
drop policy if exists tasks_select on public.tasks;
drop policy if exists tasks_insert on public.tasks;
drop policy if exists tasks_update on public.tasks;
drop policy if exists tasks_delete on public.tasks;

create policy tasks_select on public.tasks
  for select to authenticated
  using (public.app_is_active());

create policy tasks_insert on public.tasks
  for insert to authenticated
  with check (
    public.app_is_active()
    and created_by = auth.uid()
    and (public.app_is_admin() or assignee_id is null or assignee_id = auth.uid())
  );

create policy tasks_update on public.tasks
  for update to authenticated
  using (
    public.app_is_active()
    and (public.app_is_admin() or created_by = auth.uid() or assignee_id = auth.uid())
  )
  with check (
    public.app_is_active()
    and (public.app_is_admin() or created_by = auth.uid() or assignee_id = auth.uid())
  );

create policy tasks_delete on public.tasks
  for delete to authenticated
  using (public.app_is_admin());


-- ---------------------------------------------------------------------
-- 6. REALTIME (as mudanças respeitam o RLS acima)
-- ---------------------------------------------------------------------

do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    if not exists (select 1 from pg_publication_tables
                   where pubname = 'supabase_realtime'
                     and schemaname = 'public' and tablename = 'tasks') then
      alter publication supabase_realtime add table public.tasks;
    end if;
    if not exists (select 1 from pg_publication_tables
                   where pubname = 'supabase_realtime'
                     and schemaname = 'public' and tablename = 'profiles') then
      alter publication supabase_realtime add table public.profiles;
    end if;
  end if;
end $$;


-- ---------------------------------------------------------------------
-- 7. USUÁRIOS QUE JÁ EXISTIAM ANTES DESTE SCRIPT
--    (cria o perfil de quem já estava em Authentication → Users)
-- ---------------------------------------------------------------------

insert into public.profiles (id, email, full_name)
select u.id,
       coalesce(u.email, ''),
       left(coalesce(nullif(btrim(u.raw_user_meta_data ->> 'full_name'), ''),
                     split_part(coalesce(u.email, ''), '@', 1)), 120)
from auth.users u
on conflict (id) do nothing;


-- ---------------------------------------------------------------------
-- 8. PRIMEIRO ADMINISTRADOR
--    1) Authentication → Users → "Add user" → crie seu usuário
--       (marque "Auto Confirm User").
--    2) Rode UMA vez, trocando o e-mail pelo seu:
--
--         update public.profiles
--            set role = 'admin'
--          where email = 'voce@seuescritorio.com.br';
--
--    Isso só funciona no SQL Editor (conexão privilegiada). Pela API
--    do site, ninguém consegue se promover.
-- ---------------------------------------------------------------------
