// Ponto de entrada da Edge Function (Deno / Supabase). Toda a lógica está em handler.ts.
// Deploy:  supabase functions deploy admin-users
//
// Variáveis usadas (SUPABASE_URL, SUPABASE_ANON_KEY e SUPABASE_SERVICE_ROLE_KEY já são
// injetadas automaticamente pelo Supabase — não é preciso cadastrá-las):
//   SITE_URL             (opcional) endereço do site, usado como destino do link de convite
//   ALLOWED_ORIGIN       (opcional) origem(ns) autorizadas a chamar a função, separadas por vírgula
//   ALLOWED_EMAIL_DOMAIN (opcional) ex.: seuescritorio.com.br — só aceita cadastro desse domínio
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";
import { makeHandler } from "./handler.ts";

// deno-lint-ignore no-explicit-any
Deno.serve(makeHandler({ createClient, env: (k: string) => (Deno as any).env.get(k) }));
