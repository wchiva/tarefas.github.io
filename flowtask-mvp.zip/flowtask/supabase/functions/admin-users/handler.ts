// Lógica da função "admin-users" (sem imports remotos, para poder ser testada fora do Deno).
//
// Por que existe: criar/convidar usuários, redefinir senhas e banir contas exige a chave
// service_role. Essa chave NUNCA pode ir para o navegador; por isso estas operações rodam aqui,
// no servidor do Supabase, e só depois de confirmar que QUEM CHAMOU é um administrador ativo.

export interface Deps {
  // deno-lint-ignore no-explicit-any
  createClient: (url: string, key: string, options?: any) => any;
  env: (name: string) => string | undefined;
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MIN_PASSWORD = 8;
const MAX_BODY_BYTES = 10_000;
const BAN_FOREVER = "876000h"; // ~100 anos

class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

export function makeHandler(deps: Deps) {
  const allowedOrigins = (deps.env("ALLOWED_ORIGIN") ?? "").split(",").map((s) => s.trim()).filter(Boolean);

  function cors(req: Request): Record<string, string> {
    const origin = req.headers.get("origin") ?? "";
    // A autenticação é por token (não por cookie), então "*" não abre CSRF; mesmo assim
    // restringimos quando ALLOWED_ORIGIN estiver configurado.
    const allow = allowedOrigins.length === 0 ? "*" : (allowedOrigins.includes(origin) ? origin : allowedOrigins[0]);
    return {
      "Access-Control-Allow-Origin": allow,
      "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
      "Vary": "Origin",
    };
  }

  function json(req: Request, status: number, body: unknown): Response {
    return new Response(JSON.stringify(body), {
      status,
      headers: { ...cors(req), "Content-Type": "application/json", "Cache-Control": "no-store" },
    });
  }

  const str = (v: unknown, max: number): string => (typeof v === "string" ? v.trim().slice(0, max) : "");

  function checkEmail(raw: unknown): string {
    const email = str(raw, 254).toLowerCase();
    if (!EMAIL_RE.test(email)) throw new HttpError(400, "Informe um e-mail válido.");
    const domain = (deps.env("ALLOWED_EMAIL_DOMAIN") ?? "").trim().toLowerCase().replace(/^@/, "");
    if (domain && !email.endsWith("@" + domain)) {
      throw new HttpError(400, `Somente e-mails @${domain} podem ser cadastrados.`);
    }
    return email;
  }

  function checkPassword(raw: unknown): string {
    if (typeof raw !== "string" || raw.length < MIN_PASSWORD || raw.length > 128) {
      throw new HttpError(400, `A senha precisa ter entre ${MIN_PASSWORD} e 128 caracteres.`);
    }
    return raw;
  }

  function checkUuid(raw: unknown): string {
    if (typeof raw !== "string" || !UUID_RE.test(raw)) throw new HttpError(400, "Usuário inválido.");
    return raw.toLowerCase();
  }

  // deno-lint-ignore no-explicit-any
  function mapError(e: any): HttpError {
    if (e instanceof HttpError) return e;
    const msg = String(e?.message ?? e ?? "");
    const code = String(e?.code ?? "");
    if (code === "email_exists" || /already (been )?registered|already exists/i.test(msg)) {
      return new HttpError(409, "Já existe um usuário com este e-mail.");
    }
    if (code === "weak_password" || /password/i.test(msg) && /(least|weak|short)/i.test(msg)) {
      return new HttpError(400, `A senha é fraca. Use pelo menos ${MIN_PASSWORD} caracteres.`);
    }
    if (code === "over_email_send_rate_limit" || e?.status === 429 || /rate limit/i.test(msg)) {
      return new HttpError(429, "Limite de envio de e-mails atingido. Aguarde ou configure um SMTP próprio no Supabase.");
    }
    // mensagens em português levantadas pelos triggers do banco (ex.: "pelo menos um administrador ativo")
    if (/administrador/i.test(msg) && (code === "P0001" || code === "42501")) return new HttpError(409, msg);
    console.error("[admin-users] erro interno:", code, msg);
    return new HttpError(500, "Não foi possível concluir a operação. Tente novamente.");
  }

  return async function handle(req: Request): Promise<Response> {
    if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors(req) });
    if (req.method !== "POST") return json(req, 405, { error: "Método não permitido." });

    try {
      const url = deps.env("SUPABASE_URL");
      const anonKey = deps.env("SUPABASE_ANON_KEY");
      const serviceKey = deps.env("SUPABASE_SERVICE_ROLE_KEY");
      if (!url || !anonKey || !serviceKey) throw new Error("Variáveis do Supabase ausentes na função.");

      // ---------- 1. quem está chamando?
      const authHeader = req.headers.get("authorization") ?? "";
      const jwt = /^Bearer\s+(.+)$/i.exec(authHeader)?.[1];
      if (!jwt) throw new HttpError(401, "Faça login para continuar.");

      const caller = deps.createClient(url, anonKey, {
        global: { headers: { Authorization: `Bearer ${jwt}` } },
        auth: { persistSession: false, autoRefreshToken: false },
      });
      const { data: userData, error: userErr } = await caller.auth.getUser(jwt);
      const uid: string | undefined = userData?.user?.id;
      if (userErr || !uid) throw new HttpError(401, "Sessão inválida ou expirada. Entre novamente.");

      const admin = deps.createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });

      // ---------- 2. é administrador ATIVO? (consulta no banco, nunca confia no corpo da requisição)
      const { data: me, error: meErr } = await admin.from("profiles").select("role,is_active").eq("id", uid).maybeSingle();
      if (meErr) throw meErr;
      if (!me || !me.is_active || me.role !== "admin") {
        throw new HttpError(403, "Somente administradores podem executar esta ação.");
      }

      // ---------- 3. corpo da requisição
      const raw = await req.text();
      if (raw.length > MAX_BODY_BYTES) throw new HttpError(413, "Requisição grande demais.");
      // deno-lint-ignore no-explicit-any
      let body: any;
      try {
        body = JSON.parse(raw);
      } catch {
        throw new HttpError(400, "Requisição inválida.");
      }
      if (!body || typeof body !== "object") throw new HttpError(400, "Requisição inválida.");

      // deno-lint-ignore no-explicit-any
      const patchProfile = async (id: string, patch: Record<string, any>) => {
        const { error } = await admin.from("profiles").update(patch).eq("id", id);
        if (error) throw error;
      };

      switch (body.action) {
        // ------------------------------------------------ cadastrar com senha temporária
        case "create": {
          const email = checkEmail(body.email);
          const password = checkPassword(body.password);
          const full_name = str(body.full_name, 120);
          const job_title = str(body.job_title, 120);
          const role = body.role === "admin" ? "admin" : "member";
          if (!full_name) throw new HttpError(400, "Informe o nome.");

          const { data, error } = await admin.auth.admin.createUser({
            email, password, email_confirm: true, user_metadata: { full_name },
          });
          if (error) throw error;
          const newId: string = data.user.id;
          try {
            // o perfil já foi criado pelo trigger (sempre como 'member'); aqui definimos o papel
            await patchProfile(newId, { full_name, job_title, role, must_change_password: true });
          } catch (e) {
            await admin.auth.admin.deleteUser(newId); // não deixa usuário "meio criado"
            throw e;
          }
          return json(req, 200, { ok: true, user_id: newId });
        }

        // ------------------------------------------------ convite por e-mail
        case "invite": {
          const email = checkEmail(body.email);
          const full_name = str(body.full_name, 120);
          const job_title = str(body.job_title, 120);
          const role = body.role === "admin" ? "admin" : "member";
          if (!full_name) throw new HttpError(400, "Informe o nome.");
          const redirectTo = deps.env("SITE_URL") || req.headers.get("origin") || undefined;

          const { data, error } = await admin.auth.admin.inviteUserByEmail(email, {
            data: { full_name }, redirectTo,
          });
          if (error) throw error;
          const newId: string = data.user.id;
          try {
            await patchProfile(newId, { full_name, job_title, role });
          } catch (e) {
            await admin.auth.admin.deleteUser(newId);
            throw e;
          }
          return json(req, 200, { ok: true, user_id: newId });
        }

        // ------------------------------------------------ redefinir senha de outra pessoa
        case "reset_password": {
          const id = checkUuid(body.user_id);
          const password = checkPassword(body.password);
          if (id === uid) throw new HttpError(400, "Para trocar a sua própria senha, use a opção de recuperação de senha.");
          const { error } = await admin.auth.admin.updateUserById(id, { password });
          if (error) throw error;
          await patchProfile(id, { must_change_password: true });
          return json(req, 200, { ok: true });
        }

        // ------------------------------------------------ ativar / desativar
        case "set_active": {
          const id = checkUuid(body.user_id);
          if (typeof body.active !== "boolean") throw new HttpError(400, "Informe se o usuário deve ficar ativo.");
          if (id === uid) throw new HttpError(400, "Você não pode alterar o seu próprio status.");
          if (body.active) {
            // reativar: libera o login e depois o acesso aos dados
            const { error } = await admin.auth.admin.updateUserById(id, { ban_duration: "none" });
            if (error) throw error;
            await patchProfile(id, { is_active: true });
          } else {
            // desativar: o perfil vem primeiro (o banco recusa se for o último admin ativo)
            await patchProfile(id, { is_active: false });
            const { error } = await admin.auth.admin.updateUserById(id, { ban_duration: BAN_FOREVER });
            if (error) throw error;
          }
          return json(req, 200, { ok: true });
        }

        default:
          throw new HttpError(400, "Ação desconhecida.");
      }
    } catch (e) {
      const err = mapError(e);
      return json(req, err.status, { error: err.message });
    }
  };
}
